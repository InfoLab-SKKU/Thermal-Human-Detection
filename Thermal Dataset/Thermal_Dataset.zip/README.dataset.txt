# cleanedauto > 2022-09-15 7:34am
https://universe.roboflow.com/object-detection/cleanedauto

Provided by Roboflow
License: CC BY 4.0

