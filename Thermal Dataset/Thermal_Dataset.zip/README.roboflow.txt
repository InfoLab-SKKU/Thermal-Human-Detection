
cleanedauto - v5 2022-09-15 7:34am
==============================

This dataset was exported via roboflow.com on September 15, 2022 at 2:52 PM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

It includes 3755 images.
Person are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 24x32 (Stretch)

No image augmentation techniques were applied.


